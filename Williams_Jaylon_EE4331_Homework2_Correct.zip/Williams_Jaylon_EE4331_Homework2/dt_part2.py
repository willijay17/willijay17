#****************************************************************************************************
#
# Jaylon Williams
# EE4331 - HW#2
# Filename: dt_part2.py
# Due: 9/22/21
#
# Objective:
# To model data using the best combination of features to determine quality through DT learning.
#
#****************************************************************************************************

#Importing all required libraries
from sklearn import datasets
import numpy as np
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
from sklearn.linear_model import Perceptron
from sklearn.metrics import accuracy_score
from sklearn.tree import DecisionTreeClassifier
import matplotlib.pyplot as plt
import pandas as pd
from matplotlib.colors import ListedColormap


#Reading and labeling the dataset, creating dataframe**********Need to match address of read to file location for testing*****************
cars = pd.read_csv(r'/home/jdw241/HW2/car_values.csv',header=None, encoding='utf-8')
cars.columns = ['cost' , 'maint', 'doors', 'persons' , 'luggage', 'safety', 'rating']
#Assigning int values to strings in docs
size_mapping_prices = {'vhigh' : 4, 'high' : 3, 'med' : 2, 'low' : 1}
cars['maint'] = cars['maint'].map(size_mapping_prices)
cars['cost'] = cars['cost'].map(size_mapping_prices)
#changing safety parameters to pass or fail
size_mapping_safety = {'low' : 1, 'med' : 2, 'high' : 3}
cars['safety'] = cars['safety'].map(size_mapping_safety)
size_mapping_acceptance = {'unacc' : 0, 'acc' : 1, 'good' : 1, 'vgood' : 1}
cars['rating'] = cars['rating'].map(size_mapping_acceptance)
size_mapping_doors = {'1' : 1 , '2' : 2, '3' : 3, '4' : 4, '5more' : 5}
cars['doors'] = cars['doors'].map(size_mapping_doors)
size_mapping_persons = {'1' : 1 , '2' : 2, '3' : 3, '4' : 4, 'more' : 5}
cars['persons'] = cars['persons'].map(size_mapping_persons)
size_mapping_luggage = {'small' : 1, 'med' : 2, 'big' : 3}
cars['luggage'] = cars['luggage'].map(size_mapping_luggage)
print(cars)
#Separating data & target information
X = cars.iloc[:,[3,5]]
y = cars.iloc[:,6]

#Data split for training and testing
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.35, 
random_state=1, stratify=y)
#Scaling training data
sc = StandardScaler()
sc.fit(X_train)
X_train_std = sc.transform(X_train)
#Creating perceptron with hyperparameters
tree = DecisionTreeClassifier(criterion= 'gini', max_depth=2, random_state=1)
#Scaling test data
sc.fit(X_test)
X_test_std = sc.transform(X_test)
#This is training the model
tree.fit(X_train_std, y_train) 
#Testing the model data
y_pred = tree.predict(X_test_std)

print('Misclassified samples: %d' % (y_test!= y_pred).sum())
print('Training Accuracy: %.2f' % tree.score(X_train_std, y_train))
print('Test Accuracy: %.2f' % accuracy_score(y_test, y_pred))
#writing results to a file**********Need to match address of write to file location for testing*****************
file1 = open(r"home/jdw241/HW2/Accuracy_Results_DT_Bash.txt", "w+")
file1.write('Misclassified samples: %d' % (y_test!= y_pred).sum())
file1.write('\nTraining Accuracy: %.2f' % tree.score(X_train_std, y_train))
file1.write('\nTest Accuracy: %.2f' % tree.score(X_test_std, y_test))
file1.close()

#creating graph with classifications
def plot_decision_regions(X, y, classifier, test_idx=None, resolution=0.02):
    # setup marker generator and color map
    markers = ('s', 'x')
    colors = ('red', 'lightgreen')
    cmap = ListedColormap(colors[:len(np.unique(y))])
    # plot the decision surface
    x1_min, x1_max = X[:, 0].min() - 1, X[:, 0].max() + 1
    x2_min, x2_max = X[:, 1].min() - 1, X[:, 1].max() + 1
    xx1, xx2 = np.meshgrid(np.arange(x1_min, x1_max, resolution),
                           np.arange(x2_min, x2_max, resolution))
    Z = classifier.predict(np.array([xx1.ravel(), xx2.ravel()]).T)
    Z = Z.reshape(xx1.shape)
    plt.contourf(xx1, xx2, Z, alpha=0.3, cmap=cmap)
    plt.xlim(xx1.min(), xx1.max())
    plt.ylim(xx2.min(), xx2.max())
    
    # plot class examples
    for idx, cl in enumerate(np.unique(y)):
        plt.scatter(x=X[y == cl, 0], y=X[y == cl, 1],
                    alpha=0.8, c=colors[idx],
                    marker=markers[idx], label=cl,
                    edgecolor='black')
    
        # highlight test examples

#labeling graph
X_combined_std = np.vstack((X_train_std, X_test_std))
y_combined = np.hstack((y_train, y_test))
plot_decision_regions(X_combined_std, y_combined, classifier=tree,test_idx=range(105, 150))
plt.xlabel('car persons [standardized]')
plt.ylabel('car safety rating[standardized]')
plt.legend(loc='upper left')
plt.savefig('Best_Plot_DT.png')
plt.show()
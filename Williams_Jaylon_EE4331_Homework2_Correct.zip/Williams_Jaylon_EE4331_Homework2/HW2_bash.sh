#!/bin/bash

#SBATCH --job-name=JWilliams_HW2
#SBATCH --partition=shared
#SBATCH --nodes=1
#SBATCH --mem=10Gb
#SBATCH --time=00:10:00

# This are bash commands == Linux terminal commands
# These outputs get recorded on the .out file
echo ""
echo "Starting at `date`"
echo "Running on hosts: $SLURM_NODELIST"
echo "Running on $SLURM_NNODES nodes."
echo "Running on $SLURM_NPROCS processors."

# Move to the correct directory
cd /home/jdw241/HW2
echo "Current working directory is `pwd`"


# Train & Test the LR model
python svm_part1.py
python dt_part2.py
python rf_part3.py


# end of the program
echo ""
echo "Program finished with exit code $? at: `date`"
echo ""